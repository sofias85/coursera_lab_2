import { render, screen } from '@testing-library/react';
import App from './App';

describe('App Component', () => {
  test('renders the main heading', () => {
    render(<App />);
    const headingElement = screen.getByRole('heading', { name: /welcome/i });
    expect(headingElement).toBeInTheDocument();
  });

  test('renders the contact section', () => {
    render(<App />);
    const contact = screen.getByText(/contact/i);
    expect(contact).toBeInTheDocument();
  });

  test('renders the projects section', () => {
    render(<App />);
    const projects = screen.getByText(/projects/i);
    expect(projects).toBeInTheDocument();
  });

  test('renders footer', () => {
    render(<App />);
    const footerText = screen.getByText(/© 2025/i);
    expect(footerText).toBeInTheDocument();
  });
});
